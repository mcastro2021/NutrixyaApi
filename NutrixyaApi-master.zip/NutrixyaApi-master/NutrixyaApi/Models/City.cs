﻿namespace NutrixyaApi.Models
{
    public class City : IdDescription
    {
        public int ProvinceId { get; set; }
    }
}
