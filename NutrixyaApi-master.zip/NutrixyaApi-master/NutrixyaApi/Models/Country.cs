﻿namespace NutrixyaApi.Models
{
    public class Country:IdDescription
    {
    }
}
